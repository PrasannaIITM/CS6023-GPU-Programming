#!/bin/bash

CURRENT_DIR="Evaluation_script"
INPUT="Evaluation_script/testcases/input"
OUTPUT="Evaluation_script/testcases/output"

touch "A3-Marks.txt"
MARKSFILE="A3-Marks.txt"

echo "====================START==========================" >> "$MARKSFILE"
date >> "$MARKSFILE"

	
ROLLNO="a3"
LOGFILE=${ROLLNO}.log

nvcc ${ROLLNO}.cu -arch=sm_37  -o A3

if [ $? -ne 0 ] 
then
  echo ${ROLLNO}, BUILD FAILED!
    echo ${ROLLNO}, BUILD FAILED! >> "$MARKSFILE"
  continue
fi
  
date >> "$LOGFILE"

for INPUT_FILE in $INPUT/*
do
  echo "file name"
  echo ${INPUT_FILE}
  FILE_NUM=$(echo $(basename "$INPUT_FILE") | cut -d'.' -f1 | cut -d't' -f2 )
  OUTPUT_FILE_NAME="Evaluation_script/testcases/output/output${FILE_NUM}.txt"
  echo $OUTPUT_FILE_NAME
  MY_OP="opt${FILE_NUM}.txt"
  ./A3 "$INPUT_FILE" "$MY_OP" >> "$LOGFILE"
  diff -w "$OUTPUT_FILE_NAME" "$MY_OP" > /dev/null 2>&1
  exit_code=$?
  if [ $exit_code -eq 0 ]
  then
    echo "success" >> "$LOGFILE"
  fi
done
SCORE=$(grep -ic success "$LOGFILE")
echo ${ROLLNO}, ${SCORE} 
echo ${ROLLNO}, ${SCORE} >> "$MARKSFILE"

date >> "$MARKSFILE"
echo "====================DONE!==========================" >> "$MARKSFILE"
